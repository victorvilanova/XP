<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Linhas de Idioma para Paginação
    |--------------------------------------------------------------------------
    |
    | As seguintes linhas de idioma são usadas pela biblioteca de paginação para construir
    | os links de paginação simples. Você é livre para modificá-las para personalizar
    | suas views e melhorar a integração com sua aplicação.
    |
    */

    'previous' => '&laquo; Anterior',
    'next' => 'Próximo &raquo;',

];